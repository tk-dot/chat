var satu = 'img';
var dua = 'audio';
var tiga = 'video';
var empat = 'input';
var lima = 'button';
var enam = 'textarea';
var tujuh = 'iframe';
var delapan = 'source';
var sembilan = 'embed';
var sepuluh = 'form';
var sebelas = 'track';

var regnlert = document.getElementById('register-name');
var connlert = document.getElementById('input-nama');
var carlert = document.getElementById('input-cari');
var carglert = document.getElementById('grup-input-cari');
var grpnlert = document.getElementById('input-grup-nama');
var chtlert = document.getElementById('input-chat');
var chtglert = document.getElementById('grup-input-chat');
var gllert = document.getElementById('gl-input-chat');
var regblert = document.getElementById('register-bio');
var conblert = document.getElementById('input-bio');
var feedlert = document.getElementById('info-feed');

regnlert.onkeydown = function () {
    if (regnlert.value.includes(satu) || regnlert.value.includes(dua) || regnlert.value.includes(tiga) || regnlert.value
        .includes(empat) || regnlert.value.includes(lima) || regnlert.value.includes(enam) || regnlert.value.includes(
            tujuh) || regnlert.value.includes(delapan) || regnlert.value.includes(sembilan) || regnlert.value.includes(
            sepuluh) ||
        regnlert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
connlert.onkeydown = function () {
    if (connlert.value.includes(satu) || connlert.value.includes(dua) || connlert.value.includes(tiga) || connlert.value
        .includes(empat) || connlert.value.includes(lima) || connlert.value.includes(enam) || connlert.value.includes(
            tujuh) || connlert.value.includes(delapan) || connlert.value.includes(sembilan) || connlert.value.includes(
            sepuluh) ||
        connlert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
carlert.onkeydown = function () {
    if (carlert.value.includes(satu) || carlert.value.includes(dua) || carlert.value.includes(tiga) || carlert.value
        .includes(empat) || carlert.value.includes(lima) || carlert.value.includes(enam) || carlert.value.includes(
            tujuh) || carlert.value.includes(delapan) || carlert.value.includes(sembilan) || carlert.value.includes(
            sepuluh) ||
        carlert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
carglert.onkeydown = function () {
    if (carglert.value.includes(satu) || carglert.value.includes(dua) || carglert.value.includes(tiga) || carglert.value
        .includes(empat) || carglert.value.includes(lima) || carglert.value.includes(enam) || carglert.value.includes(
            tujuh) || carglert.value.includes(delapan) || carglert.value.includes(sembilan) || carglert.value.includes(
            sepuluh) ||
        carglert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
grpnlert.onkeydown = function () {
    if (grpnlert.value.includes(satu) || grpnlert.value.includes(dua) || grpnlert.value.includes(tiga) || grpnlert.value
        .includes(empat) || grpnlert.value.includes(lima) || grpnlert.value.includes(enam) || grpnlert.value.includes(
            tujuh) || grpnlert.value.includes(delapan) || grpnlert.value.includes(sembilan) || grpnlert.value.includes(
            sepuluh) ||
        grpnlert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
chtlert.onkeydown = function () {
    if (chtlert.value.includes(satu) || chtlert.value.includes(dua) || chtlert.value.includes(tiga) || chtlert.value
        .includes(empat) || chtlert.value.includes(lima) || chtlert.value.includes(enam) || chtlert.value.includes(
            tujuh) || chtlert.value.includes(delapan) || chtlert.value.includes(sembilan) || chtlert.value.includes(
            sepuluh) ||
        chtlert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
chtglert.onkeydown = function () {
    if (chtglert.value.includes(satu) || chtglert.value.includes(dua) || chtglert.value.includes(tiga) || chtglert.value
        .includes(empat) || chtglert.value.includes(lima) || chtglert.value.includes(enam) || chtglert.value.includes(
            tujuh) || chtglert.value.includes(delapan) || chtglert.value.includes(sembilan) || chtglert.value.includes(
            sepuluh) ||
        chtglert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
gllert.onkeydown = function () {
    if (gllert.value.includes(satu) || gllert.value.includes(dua) || gllert.value.includes(tiga) || gllert.value
        .includes(empat) || gllert.value.includes(lima) || gllert.value.includes(enam) || gllert.value.includes(
            tujuh) || gllert.value.includes(delapan) || gllert.value.includes(sembilan) || gllert.value.includes(
            sepuluh) ||
        gllert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
regblert.onkeydown = function () {
    if (regblert.value.includes(satu) || regblert.value.includes(dua) || regblert.value.includes(tiga) || regblert.value
        .includes(empat) || regblert.value.includes(lima) || regblert.value.includes(enam) || regblert.value.includes(
            tujuh) || regblert.value.includes(delapan) || regblert.value.includes(sembilan) || regblert.value.includes(
            sepuluh) ||
        regblert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
conblert.onkeydown = function () {
    if (conblert.value.includes(satu) || conblert.value.includes(dua) || conblert.value.includes(tiga) || conblert.value
        .includes(empat) || conblert.value.includes(lima) || conblert.value.includes(enam) || conblert.value.includes(
            tujuh) || conblert.value.includes(delapan) || conblert.value.includes(sembilan) || conblert.value.includes(
            sepuluh) ||
        conblert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}
feedlert.onkeydown = function () {
    if (feedlert.value.includes(satu) || feedlert.value.includes(dua) || feedlert.value.includes(tiga) || feedlert.value
        .includes(empat) || feedlert.value.includes(lima) || feedlert.value.includes(enam) || feedlert.value.includes(
            tujuh) || feedlert.value.includes(delapan) || feedlert.value.includes(sembilan) || feedlert.value.includes(
            sepuluh) ||
        feedlert.value.includes(sebelas)) {
        document.getElementById('alert-section').style.display = 'flex';
        document.getElementById('inside').style.display = 'none';
        document.getElementById('connect').style.display = 'none';
        return;
    }
}