const firebaseConfig = {
    apiKey: "AIzaSyDFVLs4U0WtqWqQIO5ECXuuDarXFT5e36k",
    authDomain: "login-fcffc.firebaseapp.com",
    databaseURL: "https://login-fcffc-default-rtdb.firebaseio.com",
    projectId: "login-fcffc",
    storageBucket: "login-fcffc.appspot.com",
    messagingSenderId: "666363984895",
    appId: "1:666363984895:web:b62c0bddf38c4cc8a8c5ca",
    measurementId: "G-XDYM8M2283"
    
    
    // apiKey: "AIzaSyB8SPIHdlDqj-c3_1qHEk0PEOibm9tYYT8",
    // authDomain: "messaging761.firebaseapp.com",
    // databaseURL: "https://messaging761-default-rtdb.asia-southeast1.firebasedatabase.app",
    // projectId: "messaging761",
    // storageBucket: "messaging761.appspot.com",
    // messagingSenderId: "766173576790",
    // appId: "1:766173576790:web:1a3905fc8cb7d0059045f7"
};
const app = firebase.initializeApp(firebaseConfig);
