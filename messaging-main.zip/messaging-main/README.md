<h1>LIVE MESSENGER</h1>
<hr>

**Fitur-fitur:**

>1. Mengganti Username, Bio/Tentang, Foto Profil
>2. Chat Pribadi Antar Pengguna
>3. Grup Chat
>4. Global Chat
>5. Feed/Postingan/Story
>6. Pesan suara dan gambar pada chat
>7. Menarik/Menghapus Pesan
>8. Background Chat
>9. Tema (Light/Dark)
>10. Menghapus Akun

**Rencana Selanjutnya:**
>1. Blokir User
>2. Request Friend/Remove Friend/Reject Request
>3. Voice Call & Video Call
>4. Customize Tema Sendiri
dll

**Link Ke Live Messenger:**
[LIVE MESSENGER](https://dvnkz-messenger.netlify.app/)
